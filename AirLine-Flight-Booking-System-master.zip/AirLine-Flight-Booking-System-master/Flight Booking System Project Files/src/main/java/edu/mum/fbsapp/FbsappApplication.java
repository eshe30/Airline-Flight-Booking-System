package edu.mum.fbsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FbsappApplication {

    public static void main(String[] args) {
        SpringApplication.run(FbsappApplication.class, args);
    }
}
