package edu.mum.fbsapp.edu.mum.fbsapp.service;

import edu.mum.fbsapp.edu.mum.fbsapp.model.Airline;

public interface AirlineService extends BaseService<Airline> {
}
