package edu.mum.fbsapp.edu.mum.fbsapp.service;

import edu.mum.fbsapp.edu.mum.fbsapp.model.Airport;

public interface AirportService extends BaseService<Airport> {

}
